package com.example.bookshelf.ui.screens.query_screen

data class SearchUiState(
    val query: String = "Jazz",
    val searchStarted: Boolean = false
)
